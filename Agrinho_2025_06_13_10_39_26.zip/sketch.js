function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  fill("red");
  
  text("JOSÉ ROBERTO DE OLIVEIRA MAZAR", 70, 100);
  
}